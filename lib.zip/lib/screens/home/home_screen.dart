import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../theme/app_theme.dart';
import '../../widgets/common/animated_background.dart';
import '../../widgets/layout/footer.dart';
import '../../widgets/layout/nav_bar.dart';
import '../../widgets/sections/about_section.dart';
import '../../widgets/sections/contact_section.dart';
import '../../widgets/sections/hero_section.dart';
import '../../widgets/sections/projects_section.dart';
import '../../widgets/sections/skills_section.dart';

// Provider to store keys for scrolling
final homeScrollKeysProvider = Provider<List<GlobalKey>>((ref) {
  return List.generate(5, (_) => GlobalKey());
});

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final keys = ref.watch(homeScrollKeysProvider);
    final scrollController = ScrollController();

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: const NavBar(),
      endDrawer: const _MobileDrawer(),
      body: AnimatedBackground(
        child: SingleChildScrollView(
          controller: scrollController,
          child: Column(
            children: [
              SizedBox(key: keys[0], child: const HeroSection()),
              _SectionDivider(),
              SizedBox(key: keys[1], child: const AboutSection()),
              _SectionDivider(),
              SizedBox(key: keys[2], child: const SkillsSection()),
              _SectionDivider(),
              SizedBox(key: keys[3], child: const ProjectsSection()),
              _SectionDivider(),
              SizedBox(key: keys[4], child: const ContactSection()),
              const Footer(),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionDivider extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 48),
      height: 1,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.transparent,
            AppColors.primary.withValues(alpha: 0.2),
            AppColors.accentCyan.withValues(alpha: 0.2),
            Colors.transparent,
          ],
        ),
      ),
    );
  }
}

class _MobileDrawer extends ConsumerWidget {
  const _MobileDrawer();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final keys = ref.read(homeScrollKeysProvider);
    final theme = Theme.of(context);

    return Drawer(
      backgroundColor: theme.scaffoldBackgroundColor,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.all(24),
              child: ShaderMask(
                shaderCallback: (bounds) => const LinearGradient(
                  colors: AppColors.primaryGradient,
                ).createShader(bounds),
                child: Text(
                  "Menu",
                  style: theme.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),

            const Divider(height: 1),

            // Menu items
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  _DrawerItem(
                    icon: Icons.home_rounded,
                    title: "Home",
                    onTap: () {
                      Navigator.pop(context);
                      _scrollTo(keys[0]);
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.person_rounded,
                    title: "About",
                    onTap: () {
                      Navigator.pop(context);
                      _scrollTo(keys[1]);
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.code_rounded,
                    title: "Skills",
                    onTap: () {
                      Navigator.pop(context);
                      _scrollTo(keys[2]);
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.work_rounded,
                    title: "Projects",
                    onTap: () {
                      Navigator.pop(context);
                      _scrollTo(keys[3]);
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.email_rounded,
                    title: "Contact",
                    onTap: () {
                      Navigator.pop(context);
                      _scrollTo(keys[4]);
                    },
                  ),
                ],
              ),
            ),

            // Theme toggle
            Padding(
              padding: const EdgeInsets.all(24),
              child: _ThemeToggleRow(),
            ),
          ],
        ),
      ),
    );
  }

  void _scrollTo(GlobalKey key) {
    if (key.currentContext != null) {
      Scrollable.ensureVisible(
        key.currentContext!,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    }
  }
}

class _DrawerItem extends StatefulWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  State<_DrawerItem> createState() => _DrawerItemState();
}

class _DrawerItemState extends State<_DrawerItem> {
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true),
      onExit: (_) => setState(() => _isHovered = false),
      child: InkWell(
        onTap: widget.onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: _isHovered
                ? AppColors.primary.withValues(alpha: 0.1)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Icon(
                widget.icon,
                color: _isHovered ? AppColors.primary : theme.iconTheme.color,
                size: 22,
              ),
              const SizedBox(width: 16),
              Text(
                widget.title,
                style: theme.textTheme.bodyLarge?.copyWith(
                  fontWeight: FontWeight.w500,
                  color: _isHovered
                      ? AppColors.primary
                      : theme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ThemeToggleRow extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);
    final isDark = themeMode == ThemeMode.dark;
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withValues(alpha: 0.5),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.onSurface.withValues(alpha: 0.1),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(
                isDark ? Icons.dark_mode_rounded : Icons.light_mode_rounded,
                color: isDark ? Colors.amber : Colors.indigo,
              ),
              const SizedBox(width: 12),
              Text(
                isDark ? "Dark Mode" : "Light Mode",
                style: theme.textTheme.bodyMedium,
              ),
            ],
          ),
          Switch(
            value: isDark,
            onChanged: (_) =>
                ref.read(themeModeProvider.notifier).toggleTheme(),
            activeColor: AppColors.primary,
          ),
        ],
      ),
    );
  }
}
