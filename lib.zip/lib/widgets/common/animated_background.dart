import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';

/// Animated gradient background with floating orbs
class AnimatedBackground extends StatefulWidget {
  final Widget child;

  const AnimatedBackground({super.key, required this.child});

  @override
  State<AnimatedBackground> createState() => _AnimatedBackgroundState();
}

class _AnimatedBackgroundState extends State<AnimatedBackground>
    with TickerProviderStateMixin {
  late AnimationController _controller;
  late List<_GradientOrb> _orbs;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20),
    )..repeat();

    _orbs = List.generate(4, (index) => _GradientOrb(index));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Stack(
      children: [
        // Base gradient
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: isDark
                  ? [
                      AppColors.backgroundDark,
                      const Color(0xFF0F0F1A),
                      AppColors.backgroundDark,
                    ]
                  : [
                      AppColors.backgroundLight,
                      const Color(0xFFF0F4FF),
                      AppColors.backgroundLight,
                    ],
            ),
          ),
        ),

        // Animated orbs
        ...List.generate(_orbs.length, (index) {
          return AnimatedBuilder(
            animation: _controller,
            builder: (context, child) {
              final orb = _orbs[index];
              final progress = (_controller.value + orb.offset) % 1.0;
              final x =
                  orb.startX + math.sin(progress * 2 * math.pi) * orb.radiusX;
              final y =
                  orb.startY + math.cos(progress * 2 * math.pi) * orb.radiusY;

              return Positioned(
                left: x,
                top: y,
                child: Container(
                  width: orb.size,
                  height: orb.size,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(
                      colors: [
                        orb.color.withValues(alpha: isDark ? 0.3 : 0.2),
                        orb.color.withValues(alpha: 0.0),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        }),

        // Content
        widget.child,
      ],
    );
  }
}

class _GradientOrb {
  final double startX;
  final double startY;
  final double radiusX;
  final double radiusY;
  final double size;
  final double offset;
  final Color color;

  static final _colors = [
    AppColors.accentPurple,
    AppColors.accentBlue,
    AppColors.primary,
    AppColors.accentCyan,
  ];

  _GradientOrb(int index)
    : startX = (index % 2 == 0 ? 50 : 200) + (index * 100).toDouble(),
      startY = (index % 2 == 0 ? 100 : 300) + (index * 50).toDouble(),
      radiusX = 80 + (index * 30).toDouble(),
      radiusY = 60 + (index * 20).toDouble(),
      size = 300 + (index * 100).toDouble(),
      offset = index * 0.25,
      color = _colors[index % _colors.length];
}
